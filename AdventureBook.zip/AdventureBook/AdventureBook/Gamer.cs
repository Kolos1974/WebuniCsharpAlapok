﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureBook
{
    class Gamer : Creature
    {

        public Gamer(string name, int vitality) : base(name, vitality)
        {
        }

    }
}
